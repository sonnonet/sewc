package org.techtown.diary.data;

public class Geometry {

    public GeometryLocation location;

}
