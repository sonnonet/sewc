package org.techtown.diary;

public interface OnRequestListener {
    public void onRequest(String command);
}
