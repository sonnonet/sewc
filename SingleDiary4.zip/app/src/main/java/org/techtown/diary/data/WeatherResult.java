package org.techtown.diary.data;

public class WeatherResult {

    public WeatherHeader header;
    public WeatherBody body;

}
